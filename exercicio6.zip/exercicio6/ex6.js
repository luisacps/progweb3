// traz os botoes para o arquivo js
const elemento1 = document.getElementById("btn_aluno");
const elemento2 = document.getElementById("btn_professor");
const elemento3 = document.getElementById("btn_criar_aluno");
const elemento4 = document.getElementById("btn_criar_prof");

// traz os conteudos para o js
const elemento5 = document.getElementById("ctd_aluno");
const elemento6 = document.getElementById("ctd_prof");

// oculta os elementos da tela
elemento5.style.display = none;
elemento6.style.display = none;

// adiciona os eventos aos elementos criados
elemento1.addEventListener("click", visualizarAluno());
elemento2.addEventListener("click", visualizarProfessor());

function visualizarAluno() {
    console.log("visualizarAluno");
}

function visualizarProfessor() {
    console.log("visualizarProfessor");
}

// adiciona os eventos aos elementos criados
elemento3.addEventListener("click", criarAluno());
elemento4.addEventListener("click", criarProfessor());

function criarAluno() {
    var name = prompt('Digite o nome do aluno: ');
    var aluno = document.createElement('p');
    // rotulando a tag p
    var no = document.createTextNode(`Aluno: ${name}`);
    // adicionando o rotulo na tag
    aluno.appendChild(no);

    ctd_aluno.insertBefore(aluno, elemento3);
}

function criarProfessor() {
    var name = prompt('Digite o nome do professor: ');
    var prof = document.createElement('p');
    // rotulando a tag p
    var no = document.createTextNode(`Professor: ${name}`);
    // adicionando o rotulo na tag
    prof.appendChild(no);

    ctd_prof.insertBefore(prof, elemento4);
}